^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package schunk_modular_robotics
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.14 (2019-11-20)
-------------------
* Merge pull request `#215 <https://github.com/ipa320/schunk_modular_robotics/issues/215>`_ from ipa320/indigo_release_candidate
  Indigo release candidate
* Merge branch 'indigo_dev' into indigo_release_candidate
* Merge branch 'indigo_dev' of github.com:ipa320/schunk_modular_robotics into indigo_release_candidate
* Merge pull request `#199 <https://github.com/ipa320/schunk_modular_robotics/issues/199>`_ from ipa320/indigo_dev
  Indigo dev
* Contributors: Christian Rauch, Felix Messmer, fmessmer

0.6.13 (2019-08-20)
-------------------

0.6.12 (2018-08-16)
-------------------

0.6.11 (2018-07-21)
-------------------

0.6.10 (2018-01-07)
-------------------
* Merge pull request `#198 <https://github.com/ipa320/schunk_modular_robotics/issues/198>`_ from ipa320/indigo_release_candidate
  Indigo release candidate
* Merge pull request `#196 <https://github.com/ipa320/schunk_modular_robotics/issues/196>`_ from ipa-fxm/update_maintainer
  update maintainer
* update maintainer
* Merge pull request `#191 <https://github.com/ipa320/schunk_modular_robotics/issues/191>`_ from ipa-fxm/APACHE_license
  use license apache 2.0
* use license apache 2.0
* Contributors: Felix Messmer, Florian Weisshardt, ipa-fxm

0.6.9 (2017-07-17)
------------------
* remove package schunk_sdhx
* manually fix changelog
* Contributors: ipa-fxm

0.6.8 (2016-10-10)
------------------

0.6.7 (2016-04-01)
------------------

0.6.6 (2015-09-01)
------------------

0.6.5 (2015-08-31)
------------------

0.6.4 (2015-08-25)
------------------
* migration to package format 2
* remove trailing whitespaces
* review dependencies
* Contributors: ipa-fxm

0.6.3 (2015-06-17)
------------------

0.6.2 (2014-12-15)
------------------
* Merge branch 'indigo_dev' into indigo_release_candidate
* sdhx tested
* Contributors: Florian Weisshardt, ipa-nhg

0.6.1 (2014-09-22)
------------------

0.6.0 (2014-09-18)
------------------

0.5.6 (2014-08-27)
------------------

0.5.5 (2014-08-26)
------------------
* Merge pull request `#81 <https://github.com/ipa320/schunk_modular_robotics/issues/81>`_ from ipa320/hydro_release_candidate
  bring back changes from Hydro release candidate
* New maintainer
* Contributors: Nadia Hammoudeh García, ipa-nhg

0.5.4 (2014-03-28)
------------------

0.5.3 (2014-03-27)
------------------

0.5.2 (2014-03-27)
------------------

0.5.1 (2014-03-20)
------------------
* Initial catkinization. Still a linking error in sdh lib.
* Contributors: abubeck
